package WEEK11;

public class initializeArray {
    public static void main(String[] args) {
        int[] array = {32,27,64,18,95,14,90,70,60,37};
       // System.out.printf("%s%8s\n", index)
    }
}
