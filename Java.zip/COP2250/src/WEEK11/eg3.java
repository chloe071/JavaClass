package WEEK11;

public class eg3 {
    public static void main(String[] args) {
        int[] a = new int[3];
        int[] b = new int[5];
        a[0] = 3;
        System.out.println("a[0]= "+a[0]);
        a[1] = a[0] +2;
        System.out.println("a[1]= "+a[1]);
        a[2]++;
        System.out.println("a[2]= "+a[2]);
        int x = a[2];
        System.out.println("x= "+x);
        int y = a[2] - 1;
        System.out.println("y= "+y);
        int z = a[2-1];
        System.out.println("z= "+z);
        int w = a[2]--;
        System.out.println("w= "+w);
    }
}
