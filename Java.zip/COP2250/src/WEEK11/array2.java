package WEEK11;

public class array2 {
    public static void main(String[] args) {
        int [] array2 = {10,2,3,4,6,7,9,6};
        for (int i = 0; i <array2.length; i++) {
            System.out.println(array2[i]);
        }
    }
}
