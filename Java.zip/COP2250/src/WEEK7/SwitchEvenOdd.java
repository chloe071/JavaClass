package WEEK7;

import java.util.Scanner;

public class SwitchEvenOdd {
    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);
        System.out.println("Enter a number: ");
        int even = scnr.nextInt();
        switch(even%2){
            case 0: //if number equals zero it will not be divisable
                System.out.println("Number is not divisable by 2"); break;
            case 1: //if number equals 1
            System.out.println("Number is divisable by 2");
        }
    }
}
