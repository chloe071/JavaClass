package WEEK7;

import java.util.Scanner;

public class OddEven {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter a number: ");
        int value = input.nextInt();
        if (value%5==0){
            System.out.println("Number is divisable by five");
        }
        else {
            System.out.println("Number is not divisable by five");
        }
    }
}
