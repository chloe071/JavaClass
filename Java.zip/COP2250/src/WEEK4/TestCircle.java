package WEEK4;

public class TestCircle {
    public static void main(String[] args) {

        Circle c1 =new Circle();
        System.out.println("The radius is: "+c1.radius);
        System.out.println("Area is: "+c1.getArea());
    }
}
