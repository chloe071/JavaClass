package WEEK4;

public class Circle {
    double radius;

    Circle()
    {
        radius = 10;
    }
    double getArea()
    {
        return Math.PI*radius*radius;
    }
}
