package WEEK1;

 /* this program will
 add two number
  */

public class sum {
    public static void main(String[] args) {
        System.out.print("2+3 = "); // to print only
                System.out.println(2+3); // to calculate
    }
}
