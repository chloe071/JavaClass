package WEEK1;

public class Task1 {
    public static void main(String[] args) {
        System.out.print("1+2+3+4+5+6+7+8+9 = "); //to print only
        System.out.println(1+2+3+4+5+6+7+8+9); //to calculate
    }
}
