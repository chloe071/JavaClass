package WEEK1;

public class Task3 {
    public static void main(String[] args) {
        //Display the pattern "JAVA"
        System.out.println("   J   a   v    v   a");
        System.out.println("   J  a a   v  v   a a");
        System.out.println("J  J aaaaa   V V  aaaaa");
        System.out.println(" JJ a     a   V  a     a");
    }
}
