package WEEK1;

public class Hello { //this program prints hello
    public static void main(String[] args) {
        System.out.println("Hello!"); //print hello
          System.out.println("My name is Chloe"); //print name
    }
}
