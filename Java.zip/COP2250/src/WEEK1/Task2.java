package WEEK1;

public class Task2 {
    public static void main(String[] args) {
        System.out.print("9.5*4.5-2.5*3/45.5-3.5 = "); //print only
        System.out.println(9.5*4.5-2.5*3/45.5-3.5); //calculate
    }
}
