package WEEK1;

public class expressions {
    public static void main(String[] args) {
        System.out.print(" 9.5*");
    }
}
