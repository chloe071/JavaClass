package zylabs;
import java.util.Scanner;
/*
 * HEADER COMMENT BLOCK
 * AUTHOR: CHLOE CEDANO
 * COURSE: COP2250
 * DATE: 1/21/25
 * ASSIGNMENT: 3.1 ZYLAB H
 * INSTRUCTOR: SERGIO PISANO
 * DESCRIPTION: This program calculates and outputs the average calories burned for a person.
 */

public class LabProgram {
    public static void main(String[] args) {
        //Create a Scanner object to read input
        Scanner scnr = new Scanner(System.in);

        //Read inputs: age, weight, heart rate, time
        int age = scnr.nextInt();
        double weight = scnr.nextDouble();
        double heartRate = scnr.nextDouble();
        double time = scnr.nextDouble();

        //Calculate calories burned using the formula
        double calories = ((age * 0.2757) + (weight * 0.03295) + (heartRate * 1.0781) - 75.4991) * time / 8.368;

        //Output the result formatted to two decimal places
        System.out.printf("Calories: %.2f calories\n", calories);

        //close scanner
        scnr.close();
    }
}
/*Code Output
 * Calories: 736.21 calories
 */