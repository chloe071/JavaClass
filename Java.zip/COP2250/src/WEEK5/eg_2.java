package WEEK5;

public class eg_2 {
    public static void main(String[] args) {
        String miamiFlorida="Beaches";

        int firstA=miamiFlorida.indexOf('e');
        int secondA=miamiFlorida.indexOf('e', firstA + 1);

        System.out.println("The location of the first e in Beaches is " + firstA);
        System.out.println("The location of the second e in Cantata is " + secondA);

    }
}
