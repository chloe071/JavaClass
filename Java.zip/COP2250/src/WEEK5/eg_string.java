package WEEK5;

public class eg_string {
    public static void main(String [] args) {
        String s="Florida International University";
        System.out.println(s.indexOf('i'));
        System.out.println(s.indexOf('i', 6));
        System.out.print(s.indexOf("er"));
    }
}
