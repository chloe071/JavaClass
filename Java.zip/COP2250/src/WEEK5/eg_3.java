package WEEK5;

public class eg_3 {
    public static void main(String[] args) {

        String a= "florida";
        String b= "International";
        String c="INTERNATIONAL";

        System.out.println(a.toUpperCase());
        System.out.println(c.toLowerCase());

        System.out.println(a+b);
        System.out.println(a.concat(c));
    }
}
