package WEEK8;

public class ex_loop {
    public static void main(String[] args) {
        int sum=0;
        for (int a=1; a<=10; a++)
        {
            sum = sum +a;
        }
        System.out.println("Sum ="+ sum);
    }
}
