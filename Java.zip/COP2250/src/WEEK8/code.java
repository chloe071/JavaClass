package WEEK8;

public class code {
    public static void main(String[] args) {
        int q = 0;
        for (int p = 1; p < 3; p++)
            q++;
        q += 2;
        System.out.println("q: " + q);
    }
}
