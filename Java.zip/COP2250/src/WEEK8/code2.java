package WEEK8;

public class code2 {
    public static void main(String[] args) {
        int sumY = 4;
        int yIncrement = 3;
        for (int y = 0; y <= 10; y += yIncrement) {
            sumY += y;

        }
        System.out.println("sumY: " + sumY);
    }
}
