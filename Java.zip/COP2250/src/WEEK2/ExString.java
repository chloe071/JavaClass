package WEEK2;

import java.util.Scanner;

public class ExString {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int x,y,sum;
        System.out.print("Enter number 1: "); //print first number
        x= input.nextInt();
        System.out.print("Enter number 2: "); //print second number
        y= input.nextInt();
        sum=x+y;

        double average = (double) sum /2;

        String message = "Sum is: ";
        System.out.printf("%s %d\n", message, sum);
        System.out.printf("Average is %.2f\n", average);

    }
}
