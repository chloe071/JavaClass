package WEEK2;

import javax.swing.*;

public class ExOption {
    public static void main(String[] args) {
        JOptionPane.showInputDialog(null);

        String name;
        name = JOptionPane.showInputDialog("Enter your name");
        System.out.println("Name" + name);
    }
}