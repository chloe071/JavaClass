package WEEK2;

import java.util.Scanner;

public class ExString2 {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        String name, profession;
        char gender;

        System.out.print("Enter your Name: ");
        name = keyboard.nextLine();
        System.out.print("Enter your Profession:");
        profession = keyboard.nextLine();
        System.out.println("Name: " +name);
        System.out.println("Profession: " +profession);

        System.out.print("Enter your gender");
        gender = keyboard.next().charAt(0);
        System.out.println("-------");
        System.out.printf("%c", "Gender: ", gender);

    }
}
