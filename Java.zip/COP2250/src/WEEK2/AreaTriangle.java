package WEEK2;

public class AreaTriangle {
    public static void main(String[] args) {
        double H =15.5;
        double B =8.4;
        double Area;
        Area=0.5*H*B;
        System.out.println("Area of triangle= " +Area);
    }
}
