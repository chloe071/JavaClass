package WEEK2;

public class Addition {
    public static void main(String[] args) {
        int x =10;
        int y =25;
        int sum;
        sum=x+y;
        System.out.println("Sum is = " +sum);
        System.out.println("Sum of " +x+ "and" +y+ "= " +sum);
    }
}
