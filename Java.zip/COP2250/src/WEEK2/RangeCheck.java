package WEEK2;

public class RangeCheck {
    public static void main(String[] args) {
        int x= 15;
        byte y= -128;
        short z=32767;
        int a=214748364;
        char xyz='M';
        double b=23.5;
        boolean answer = true;

    }
}
