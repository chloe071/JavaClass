package WEEK3;

public class eg_Scope {
    public static void main(String[] args) {
        int a=4;
        int b=5;
        { //block2
            int c=8;
            int d=7;
            int sum2=c+d;
        }
        int sum1=a+b;


    }
}
