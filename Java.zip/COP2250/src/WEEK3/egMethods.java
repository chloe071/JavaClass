package WEEK3;

public class egMethods {
    static void myMethod(){
      System.out.println("I am your first method");
      System.out.println("I am at your service");
    }
    public static void main(String[] args){
        System.out.println("Hello");
        myMethod();
    }

}
