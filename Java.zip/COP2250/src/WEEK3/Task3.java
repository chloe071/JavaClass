package WEEK3;

import java.util.Scanner;

public class Task3 {
  public static double lapsToMiles(double userlaps){
      return userlaps / 4.00;
  }

    public static void main(String[] args) {
       Scanner scnr =  new Scanner(System.in);
       double userLaps;
       userLaps = scnr.nextDouble();
       System.out.printf("%.2f\n", lapsToMiles(userLaps));
    }
}
